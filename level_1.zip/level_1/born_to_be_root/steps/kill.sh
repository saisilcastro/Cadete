ps -aux #list all processess
number=0 #kill process number
sudo kill $number
