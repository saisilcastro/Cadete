port=4242
user=lde-cast
ip=10.11.200.17
ssh -p $port $user@$ip
