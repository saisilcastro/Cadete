mac=$1
gedit /var/lib/bluetooth/$mac/config/info
