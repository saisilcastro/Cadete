app="./pipex"
$app infile "cat -a -b -c -d -e -f" "wc -w -s -t -u" "ls -l -m -n" "fucker -s -t -a --sucker" outfile