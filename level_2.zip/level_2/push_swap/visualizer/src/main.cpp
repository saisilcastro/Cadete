#include "gui.h"

int main() {
    Gui gui;
    gui.loop();
    return 0;
}
