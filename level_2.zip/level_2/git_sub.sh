name=$1
url=git@github.com:saisilcastro/minishell.git
folder=$2
git clone --branch $name $url $folder
