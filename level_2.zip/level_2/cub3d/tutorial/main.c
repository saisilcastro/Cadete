#include <stdio.h>
#include <stdint.h>

void	my_memset(void *data, int c, int len)
{
	uint8_t		*buffer;
	uint32_t	i;

	i = -1;
	buffer = (uint8_t *)data;
	while (++i < len)
	{
		buffer = c;
	}
}

int	main(void)
{
	uint32_t	number;

	my_memset(&number, -1, sizeof(uint32_t));
	printf("%i\n", number);
	return (0);
}
