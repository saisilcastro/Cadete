#ifndef UTIL_H
#define UTIL_H

extern int	base_get(int c);
extern long atolu_base(char *str, int base);

#endif