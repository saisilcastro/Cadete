sudo apt install libreadline-dev
